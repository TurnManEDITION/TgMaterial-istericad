import re
while True:
    ans = input("1 - Из слова в ASCII\n"
                "2 - Из ASCII в слова\n\t")
    if len(ans) == 1:
        if int(ans) == 1:
            text = input("Из слова в ASCII:\n")
            retry = ''
            i = 1
            o = 0
            while True:
                if len(text) >= i:
                    a = text[o]
                    retry = retry+str(ord(a))+' '
                    i += 1
                    o += 1
                else:
                    print(retry, "\n")
                    print(retry, "\n")
                    del i, o
                    break
        elif int(ans) == 2:
            text = input("Из ASCII в слова:\n")
            retry = ''
            i = 1
            o = 0
            while True:
                if int(len(text.split())) == o:
                    print(retry)
                    break
                word = re.findall(r'\w+', text)[o]
                word = int(word)
                retry = retry + str(chr(word)) + ''
                o += 1
                i += 1
