import random
import string

letters = string.ascii_letters  # "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
numbers = "1234567890"
symbols = "`~!@#$%^&*()_+-=№;:?"

while True:
    try:
        lenPass = int(input("Enter how many characters in the password: "))
        if 0 < lenPass <= 50:
            break
        else:
            print("Max chars - 50")
    except ValueError:
        print("Error!")

i = lenPass
while True:
    password = ''
    while lenPass != 0:
        lenPass -= 1
        randchar = random.choice(f"{letters}{numbers}{symbols}")
        password += randchar
    lenPass = i
    print(password)
    print("Len pass:", len(password))
    input()
