﻿using System;
using System.Threading;

namespace ConsoleCS
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i = 0;            /* Создаём переменную i (int) */

            long seconds = 0;     /* Создаём переменную seconds */
            long minutes = 0;     /* Создаём переменную minutes */

            int hours = 0;        /* Создаём переменную hours */
            int days = 0;         /* Создаём переменную days */

            while (i != 1)                                             /* Создаём цикл, пока i не будет равна 1 */
            {
                Console.WriteLine($"Local date/time: {DateTime.Now}"); /* Выводим текущую системную дату */
                Console.Write("\nEnter time in minutes(max-int+): ");  /* Выводим текст ввода */
                string sMinutes = Console.ReadLine();                  /* Вводим данные */
                try                                                    /* Для перехвата ошибки формата и больших цифр */
                {
                    minutes = Convert.ToInt64(sMinutes);               /* Задаём значение iMinutes (long) */
                    if (minutes > 0)                                   /* Условие, если iMinutes больше 0 */
                    { 
                        i++;                                           /* Добавляем единицу к переменной i */
                    }
                    else                                               /* Если не выполняется условие if */
                    { 
                        Console.Clear();                               /* Очищаем консоль */
                    }
                }
                catch (System.FormatException)                         /* Если ошибка формата */
                { 
                    Console.Clear();                                   /* Очищаем консоль */
                }
                catch (System.OverflowException)                       /* Если вводное число больше, чем long */
                { 
                    Console.Clear();                                   /* Очищаем консоль */
                }
            }

            while (minutes >= 60)                                      /* Цикл, если переменная minutes больше или равна 60 */
            {
                hours++;                                               /* Добавляем единицу к переменной hours */
                minutes -= 60;                                         /* Отнимаем 60 от переменной minutes */
            }
            while (hours >= 24)                                        /* Цикл, если переменная hours больше или равна 24 */
            {
                days++;                                                /* Добавляем единицу к переменной days */
                hours -= 24;                                           /* Отнимаем 24 от переменной hours */
            }

            while (days != 0 | hours != 0 | minutes != 0 | seconds != 0)                                                                                                                     /* Если переменные не равны 0 */
            {
                Console.Clear();                                                                                                                                                             /* Очищаем консоль */
                Console.WriteLine($"Local date/time: {DateTime.Now}");                                                                                                                       /* Выводим текущую системную дату */
                string Days; string lenDays = days.ToString(); i = lenDays.Length; if (i == 1) { Days = "0" + days.ToString(); } else { Days = days.ToString(); }                            /* Настраиваем переменную days */
                string Hours; string lenHours = hours.ToString(); i = lenHours.Length; if (i == 1) { Hours = "0" + hours.ToString(); } else { Hours = hours.ToString(); }                    /* Настраиваем переменную hours */
                string Minutes; string lenMinutes = minutes.ToString(); i = lenMinutes.Length; if (i == 1) { Minutes = "0" + minutes.ToString(); } else { Minutes = minutes.ToString(); }    /* Настраиваем переменную minutes */
                string Seconds; string lenSeconds = seconds.ToString(); i = lenSeconds.Length; if (i == 1) { Seconds = "0" + seconds.ToString(); } else { Seconds = seconds.ToString(); }    /* Настраиваем переменную seconds */

                if (hours == 0 & days >= 1 & minutes == 0 & seconds == 0) { days -= 1; hours += 24; } /* Вычисление переменных days, hours */
                if (minutes == 0 & hours >= 1 & seconds == 0) { hours -= 1; minutes += 60; }          /* Вычисление переменных hours, minutes */
                if (seconds == 0 & minutes >= 1) {  minutes -= 1; seconds += 60; }                    /* Вычисление переменных minutes, seconds */

                Console.WriteLine($"{Days}:{Hours}:{Minutes}:{Seconds}");                             /* Вывод дня:часов:минут:секунд */

                seconds--;                                                                            /* Отнимаем 1 от переменной seconds */
                Thread.Sleep(950);                                                                    /* Ставим задержку кода */
            }
        }
    }
}

