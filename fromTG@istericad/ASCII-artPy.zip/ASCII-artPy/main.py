import os

try:
    import cv2
except ModuleNotFoundError:
    os.system("pip install numpy")
    os.system("pip install opencv-python")
try:
    import cv2
except ModuleNotFoundError:
    print("Please connect to the internet!")
    os.system("pause")
    exit()

string = " `.,-':<>;+!*/?%&98#"
coef = 255 / (len(string) - 1)
nameimage = input("Enter name image: ")
image = cv2.imread(f'{nameimage}')
try:
    height, width, channels = image.shape
except AttributeError:
    print("No image found(before.jpg)")
    os.system("pause")
    exit()
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
# gray_image = cv2.resize(gray_image, (30, 12))
with open("after.txt", "w") as file:
    for x in range(0, width - 1, 8):
        s = ""
        for y in range(0, height - 1, 4):
            try:
                s += string[len(string) - int(gray_image[x, y] / coef) - 1]
                continue
            except IndexError:
                pass
        if len(s) != 0:
            file.write(s + "\n")
    print("Mission accomplished!")
    os.system("pause")