import os
try:
    import hashlib
except ModuleNotFoundError:
    os.system("pip install hashlib")
try:
    import hashlib
except ModuleNotFoundError:
    print("Please connect to the internet!")
    os.system("pause")
    exit()


for i in range(10):
    Hash = input('Введите: ')
    Hash_object = hashlib.sha512(Hash.encode())
    Hash = Hash_object.hexdigest()
    Hash_object = hashlib.sha256(Hash.encode())
    Hash = Hash_object.hexdigest()
    Hash_object = hashlib.md5(Hash.encode())
    Hash = Hash_object.hexdigest()
    print(Hash)