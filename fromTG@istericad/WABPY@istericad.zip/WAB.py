ascii = ''
bins = ''
i = 1
o = 0
text = input("Enter your text> ")
while True:
	if len(text) >= i:
	    a = text[o]
	    ascii += str(ord(a))+' '
	    i += 1
	    o += 1
	else:
	    allnums = ascii.count(" ")
	    print("\nTxt:> " + text)
	    print("Nums:> " + str(allnums))
	    print("Ascii:> " + ascii)
	    del i, o
	    break
i = 0
asciiX = ascii.split()	
while not allnums == i:
	binx = asciiX[i]
	bins += str(bin(int(binx))) + "-" 
	i += 1
Xbins = bins.replace("0b", "")
print("Binare:> " + Xbins[:-1])