import math

print("Прежде чем вычислять геом. выражения ознакомьтесь с исходным кодом!")
while True:
    num1 = input('Введите 1-ое число(radius; осн.): ')
    num2 = input('Введите 2-ое число(height; бок.): ')
    z = input('Что с ними делать?: ')

    num1 = float(num1)
    if len(num2) == 0:
        num2 = 0
    num2 = float(num2)
    z = str(z)

    result = 0
    if z == '+':
        result = num1 + num2
    if z == '-':
        result = num1 - num2
    if z == '*':
        result = num1 * num2
    if z == '/':
        result = num1 / num2
    if z == '^':
        result = num1 ** num2
    # БУКВА 'P' В НАЧАЛЕ ОЗНАЧАЕТ ПЕРИМЕТР
    # БУКВА 'S' В НАЧАЛЕ ОЗНАЧАЕТ ПЛОЩАДЬ
    # БУКВА 'D' В НАЧАЛЕ ОЗНАЧАЕТ ДИАГОНАЛЬ; ДИАМЕТР
    # БУКВА 'H' В НАЧАЛЕ ОЗНАЧАЕТ ВЫСОТУ

    # ДОБОВЛЕНИЕ В КОНЦЕ БУКВЫ 'S' ОЗНАЧАЕТ КВАДРАТ
    # ДОБОВЛЕНИЕ В КОНЦЕ БУКВЫ 'C' ОЗНАЧАЕТ СФЕРА
    # ДОБОВЛЕНИЕ В КОНЦЕ БУКВ 'IT' ОЗНАЧАЕТ РАВНОСТОРОННИЙ ТРЕУГОЛЬНИК

    if z == 'ps':
        result = 2 * (num1 + num2)
    if z == 'ss':
        result = num1 * num2

    # ДИАГОНАЛЬ КВАДРАТА В РАЗРАБОТКЕ

    # if z == 'ds':
    #     result = num1 ** 2 + num2 ** 2
    #     float(round(result, 1))
    #     n = 1
    #     while True:
    #         n += 0.1
    #         float(round(n, 1))
    #         print(n)
    #         if n ** 2 == result:
    #             result = result / n
    #             print(n, ';', result)
    #             break

    if z == 'pc':
        result = 2 * 3.14 * num1
    if z == 'sc':
        result = 3.14 * num1 ** 2
    if z == 'dc':
        result = num1 * 2

    if z == 'pit':
        result = num1 * 2 + num2
    if z == 'sit':
        result = num1 * num2 / 2
    if z == 'hit':
        result = math.sqrt(4 * num2 ** 2 - num1 ** 2) / 2
    if z == '//':
        result = math.sqrt(num1)
    print(float(round(result, 2)))
